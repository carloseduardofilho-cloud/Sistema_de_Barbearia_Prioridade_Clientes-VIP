/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdlib.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
	uint32_t id;
	//client_type_t type;
	uint32_t duracao;
} ClientInfo;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define TIMER_TICK_S   (0.00078f) // 780 us
#define TIMER_MAX_CNT  (65535)
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim13;

UART_HandleTypeDef huart2;

/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Cliente */
osThreadId_t ClienteHandle;
const osThreadAttr_t Cliente_attributes = {
  .name = "Cliente",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for CriaClienteTask */
osThreadId_t CriaClienteTaskHandle;
const osThreadAttr_t CriaClienteTask_attributes = {
  .name = "CriaClienteTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for BarbeiroTask */
osThreadId_t BarbeiroTaskHandle;
const osThreadAttr_t BarbeiroTask_attributes = {
  .name = "BarbeiroTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for Vip */
osThreadId_t VipHandle;
const osThreadAttr_t Vip_attributes = {
  .name = "Vip",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for InterruptSem */
osSemaphoreId_t InterruptSemHandle;
const osSemaphoreAttr_t InterruptSem_attributes = {
  .name = "InterruptSem"
};
/* Definitions for BarbeiroSem */
osSemaphoreId_t BarbeiroSemHandle;
const osSemaphoreAttr_t BarbeiroSem_attributes = {
  .name = "BarbeiroSem"
};
/* Definitions for CorteSem */
osSemaphoreId_t CorteSemHandle;
const osSemaphoreAttr_t CorteSem_attributes = {
  .name = "CorteSem"
};
/* Definitions for sem_clientes_vip */
osSemaphoreId_t sem_clientes_vipHandle;
const osSemaphoreAttr_t sem_clientes_vip_attributes = {
  .name = "sem_clientes_vip"
};
/* Definitions for CorteVipSem */
osSemaphoreId_t CorteVipSemHandle;
const osSemaphoreAttr_t CorteVipSem_attributes = {
  .name = "CorteVipSem"
};
/* Definitions for sem_clientes_normais */
osSemaphoreId_t sem_clientes_normaisHandle;
const osSemaphoreAttr_t sem_clientes_normais_attributes = {
  .name = "sem_clientes_normais"
};
/* USER CODE BEGIN PV */
uint8_t tipo;
char buffer[64];

#define CADEIRAS_NORMAIS_LIVRES  3
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM13_Init(void);
void StartDefaultTask(void *argument);
void StartCliente(void *argument);
void StartCriaClienteTask(void *argument);
void StartBarbeiroTask(void *argument);
void StartVip(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Task_action(char message);
void CriaCliente(uint32_t id_recebido, uint32_t duracao_recebido);
void AcendeLed(void);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM13_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim13);

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of InterruptSem */
  InterruptSemHandle = osSemaphoreNew(1, 0, &InterruptSem_attributes);

  /* creation of BarbeiroSem */
  BarbeiroSemHandle = osSemaphoreNew(1, 0, &BarbeiroSem_attributes);

  /* creation of CorteSem */
  CorteSemHandle = osSemaphoreNew(1, 0, &CorteSem_attributes);

  /* creation of sem_clientes_vip */
  sem_clientes_vipHandle = osSemaphoreNew(1, 1, &sem_clientes_vip_attributes);

  /* creation of CorteVipSem */
  CorteVipSemHandle = osSemaphoreNew(1, 0, &CorteVipSem_attributes);

  /* creation of sem_clientes_normais */
  sem_clientes_normaisHandle = osSemaphoreNew(3, 3, &sem_clientes_normais_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  //defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of Cliente */
  //ClienteHandle = osThreadNew(StartCliente, NULL, &Cliente_attributes);

  /* creation of CriaClienteTask */
  CriaClienteTaskHandle = osThreadNew(StartCriaClienteTask, NULL, &CriaClienteTask_attributes);

  /* creation of BarbeiroTask */
  BarbeiroTaskHandle = osThreadNew(StartBarbeiroTask, NULL, &BarbeiroTask_attributes);

  /* creation of Vip */
  //VipHandle = osThreadNew(StartVip, NULL, &Vip_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM13 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM13_Init(void)
{

  /* USER CODE BEGIN TIM13_Init 0 */

  /* USER CODE END TIM13_Init 0 */

  /* USER CODE BEGIN TIM13_Init 1 */

  /* USER CODE END TIM13_Init 1 */
  htim13.Instance = TIM13;
  htim13.Init.Prescaler = 65535;
  htim13.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim13.Init.Period = 65535;
  htim13.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim13.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim13) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM13_Init 2 */

  /* USER CODE END TIM13_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|GPIO_PIN_9|GPIO_PIN_10, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin PA9 PA10 */
  GPIO_InitStruct.Pin = LD2_Pin|GPIO_PIN_9|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : B5_Pin */
  GPIO_InitStruct.Pin = B5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(B5_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */


//Essa função vai ser ativada pelo botão a partir de uma interrupção
void CriaCliente(uint32_t id_recebido, uint32_t duracao_recebido){
	// aloca espaço para os dados do cliente
	ClientInfo *novoCliente = malloc(sizeof(ClientInfo));

	novoCliente ->id = id_recebido;
	novoCliente ->duracao = duracao_recebido;
     // O ,0 diz que não vai ficar esperando se não tiver vaga

	if(tipo ==0){
		if(osSemaphoreAcquire(sem_clientes_normaisHandle, 0) == osOK){
				osThreadNew(StartCliente, novoCliente, &Cliente_attributes);
			}
			else{
				free(novoCliente);
			}
	}
	else{
		if(osSemaphoreAcquire(sem_clientes_vipHandle, 0) == osOK){
				osThreadNew(StartVip, novoCliente, &Vip_attributes);
			}
			else{
				free(novoCliente);
			}
	}

}



void AcendeLed(void){
	uint8_t count =  osSemaphoreGetCount(sem_clientes_normaisHandle);
	uint8_t count_vip =  osSemaphoreGetCount(sem_clientes_vipHandle);

     //Count= 2 -> 1 cliente sentado, Count = 1 -> 2 clientes sentados ...
	//if(count - count_ant <=0 ){
			if (count ==3){
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 0);
			}
			else if (count == 2){
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 1);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
			}
			else if(count ==1){
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 1);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
			}
			else if (count == 0){
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 1);
			}
			if(count_vip ==0){
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, 1);
			}
			else{
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, 0);
			}

}


//Usamos uma flag pq chamar a propria task não é ideal dado que a execução de uma interrupção deve ser rapida
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	if(GPIO_Pin == B1_Pin){
		osSemaphoreRelease(InterruptSemHandle);
		tipo = 0;
		//Ao inves de uma flag é melhor gerar um espaço num mutex ou semaforo pra task q verifica

	}
	if(GPIO_Pin ==B5_Pin ){
		osSemaphoreRelease(InterruptSemHandle);
		tipo = 1;
	}
}

float Timer_GetElapsedTime(TIM_HandleTypeDef *htim, uint32_t start)
{
    uint32_t end = __HAL_TIM_GET_COUNTER(htim);
    uint32_t elapsed_ticks;

    if (end >= start) {
        elapsed_ticks = end - start;
    } else {
        elapsed_ticks = (TIMER_MAX_CNT - start) + end + 1;
    }

    return elapsed_ticks * TIMER_TICK_S; // retorna em segundos
}


void UART_SendString(UART_HandleTypeDef *huart, const char *msg)
{
    HAL_UART_Transmit(huart, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartCliente */
/**
* @brief Function implementing the Cliente thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartCliente */
void StartCliente(void *argument)
{
  /* USER CODE BEGIN StartCliente */
	//Ele ta fazendo um cast ja que o ponteiro vem como void
	ClientInfo *info = (ClientInfo*) argument; //Carrega os argumentos únicos desta thread
	uint32_t numero = info->id;

	uint32_t start = __HAL_TIM_GET_COUNTER(&htim13);
	osSemaphoreRelease(BarbeiroSemHandle); //Acorda o barbeiro
	osSemaphoreAcquire(CorteSemHandle, osWaitForever); //Espera pelo corte acabar


	float elapsed_s = Timer_GetElapsedTime(&htim13, start);
	snprintf(buffer, sizeof(buffer), "Tempo decorrido: %.2f s\r\n", elapsed_s);	//Corte finalizado
	UART_SendString(&huart2, buffer);
	free(info); //Libera a memória do cliente

	osThreadExit(); //Encerra a task






  /* Infinite loop */
	/*
  for(;;)
  {
    osDelay(1);
  }
  */
  /* USER CODE END StartCliente */
}

/* USER CODE BEGIN Header_StartCriaClienteTask */
/**
* @brief Function implementing the CriaClienteTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartCriaClienteTask */
void StartCriaClienteTask(void *argument)
{
  /* USER CODE BEGIN StartCriaClienteTask */
	uint32_t id = 0;
	uint32_t duracao = 3000;
  /* Infinite loop */
  for(;;)
  {
	  osSemaphoreAcquire(InterruptSemHandle, osWaitForever);
	  CriaCliente(id, duracao);
	  AcendeLed();
	  id++;
  }
  /* USER CODE END StartCriaClienteTask */
}

/* USER CODE BEGIN Header_StartBarbeiroTask */
/**
* @brief Function implementing the BarbeiroTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartBarbeiroTask */
void StartBarbeiroTask(void *argument)
{
  /* USER CODE BEGIN StartBarbeiroTask */
	uint16_t count, count_vip;


  /* Infinite loop */
  for(;;)
  {


	osSemaphoreAcquire(BarbeiroSemHandle, osWaitForever); //Barbeiro espera acordar
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, 1);

	count_vip = osSemaphoreGetCount(sem_clientes_vipHandle);
	count = osSemaphoreGetCount(sem_clientes_normaisHandle);
	if(count_vip == 0){
		osSemaphoreRelease(sem_clientes_vipHandle); //Libera um fila
		AcendeLed();
		osDelay(5000); //Realizando o corte
		osSemaphoreRelease(CorteVipSemHandle); //Finalizou o corte
	}
	else{
		osSemaphoreRelease(sem_clientes_normaisHandle); //Libera um fila
		AcendeLed();
		osDelay(5000); //Realizando o corte
		osSemaphoreRelease(CorteSemHandle); //Finalizou o corte




	}
	count_vip = osSemaphoreGetCount(sem_clientes_vipHandle);
	count = osSemaphoreGetCount(sem_clientes_normaisHandle);
	if (count != 3 || count_vip != 1){
		osSemaphoreRelease(BarbeiroSemHandle);
	}
	else
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, 0);

	//REALIZA CORTE
  }
  /* USER CODE END StartBarbeiroTask */
}

/* USER CODE BEGIN Header_StartVip */
/**
* @brief Function implementing the Vip thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartVip */
void StartVip(void *argument)
{
  /* USER CODE BEGIN StartVip */
  ClientInfo *info = (ClientInfo*) argument; //Carrega os argumentos únicos desta thread


	uint32_t start = __HAL_TIM_GET_COUNTER(&htim13);
  osSemaphoreRelease(BarbeiroSemHandle); //Acorda o barbeiro
  osSemaphoreAcquire(CorteVipSemHandle, osWaitForever); //Espera pelo corte acabar

  	//Corte finalizado
  float elapsed_s = Timer_GetElapsedTime(&htim13, start);
  snprintf(buffer, sizeof(buffer), "Tempo decorrido VIP: %.2f s\r\n", elapsed_s);	//Corte finalizado
  UART_SendString(&huart2, buffer);
  free(info); //Libera a memória do cliente
  osThreadExit(); //Encerra a task

  /* Infinite loop */
  /*
  for(;;)
  {
    osDelay(1);
  }
  */
  /* USER CODE END StartVip */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
